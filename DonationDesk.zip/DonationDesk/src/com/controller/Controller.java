package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.Account;

/**
 * Servlet implementation class Controller
 */
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		if(action==null){
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		else
			doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		
		if(action.equals("login")){
			
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			
			Account account = new Account();
			boolean status = false;
			try {
				status = account.doLogin(email, password);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(status == true){
				HttpSession session = request.getSession();
				
				session.setAttribute("email", email);
				session.setAttribute("password", password);
				request.getRequestDispatcher("cashier.jsp").forward(request, response);
			}
			else{
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			
		}
		if(action.equals("sign-up")){
			request.getRequestDispatcher("sign_up.jsp").forward(request, response);
		}
		if(action.equals("sign-up-form")){
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		if(action.equals("new-user")){
			request.getRequestDispatcher("new_user.jsp").forward(request, response);
		}
		if(action.equals("new-user-form")){
			String name=request.getParameter("name");
			String email=request.getParameter("email");
			String address=request.getParameter("address");
			
			
			String city=request.getParameter("city");
			
			String phone=request.getParameter("phone");
			String pincode=request.getParameter("pincode");
			String country=request.getParameter("country");
			Account ac=new Account();
			try {
				ac.insertUser(email,name,address,city,phone,pincode,country);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(action.equals("search")){
			String	 name=request.getParameter("name");
			String	 email=request.getParameter("email");
			String	 identification=request.getParameter("identification");
			String	  phone=request.getParameter("phone");
			Account ac=new Account();
            String email2="";
            if(name==null)
            	name="x";
            if(email==null)
            	email="x";
            if(identification==null)
            	identification="0";
            if(phone==null)
            	phone="0";
            
            try {
				email2=ac.search(name,email,phone,identification);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           
            if(email2.equals("")){
            	request.getRequestDispatcher("new_user.jsp").forward(request, response);
            	 
            }
            else{
            	request.setAttribute("email", email2);
                request.getRequestDispatcher("user_search_result.jsp").forward(request, response);
            }
		}
		if(action.equals("cashier_user")){
			String email=request.getParameter("email");
			request.setAttribute("email", email);
			request.getRequestDispatcher("cashier_user.jsp").forward(request, response);
		}
		if(action.equals("transactions")){
			String email=request.getParameter("email");
			request.setAttribute("email", email);
			request.getRequestDispatcher("transactions.jsp").forward(request, response);
	}
		if(action.equals("campus")){
			request.getRequestDispatcher("campus.jsp").forward(request, response);
		}
	}

}
