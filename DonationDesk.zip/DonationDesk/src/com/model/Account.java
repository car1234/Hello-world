package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Account {
private final String dbName="frdonation";
private final String driver="com.mysql.jdbc.Driver";
private final String url="jdbc:mysql://localhost:3306/";
private final String user="root";
private final String password = "";
Connection con;

	public boolean doLogin(String email, String password) throws ClassNotFoundException, SQLException {
		dbConnect();
		String query = "Select count(*) as count from donor where email = ? and password = ?";
		PreparedStatement pstmt = con.prepareStatement(query);
		
		pstmt.setString(1, email);
		pstmt.setString(2, password);
		
		ResultSet rs = pstmt.executeQuery();
		
		int count = 0;
		while(rs.next()){
			count = rs.getInt("count");
		}
		rs.close();
		dbClose();
		if(count > 0){
			return true;
		}
		return false;
	}
	
	

	public void insertUser(String email, String name, String address,
			String city, String phone, String pincode, String country) throws Exception, SQLException {
dbConnect();
		
		String query = "insert into deskdonor(name,address,city,country,pincode,email,phone) "
				+ "values(?,?,?,?,?,?,?)";
		
		PreparedStatement pstmt = con.prepareStatement(query);
		
		pstmt.setString(1, name);
		
		pstmt.setString(2, address);
		pstmt.setString(3, city);
		pstmt.setString(4, country);
		pstmt.setString(5, pincode);
		pstmt.setString(6, email);
		pstmt.setString(7, phone);
		
		pstmt.executeUpdate();
		
		dbClose();
	
		
	}

	public String search(String name, String email, String phone,
			String identification) throws Exception, SQLException {
		dbConnect();
		String email2="";
		int ident=Integer.parseInt(identification);
		int ph=Integer.parseInt(phone);
		String query = "Select email from donor where email = ? OR phone = ? OR fname= ? OR identification= ?";
		PreparedStatement pstmt = con.prepareStatement(query);
		
		pstmt.setString(1, email);
		pstmt.setInt(2, ph);
		pstmt.setString(3, name);
		pstmt.setInt(4,ident);
		ResultSet rs = pstmt.executeQuery();
		
		
		while(rs.next()){
			email2 = rs.getString("email");
		}
		rs.close();
		dbClose();
		return email2;
		
	}

	
	private void dbConnect() throws ClassNotFoundException, SQLException{
		Class.forName(driver);
		
		con = DriverManager.getConnection(url+dbName, user, password);
	}
	
	private void dbClose() throws SQLException{
		con.close();
	}
}
